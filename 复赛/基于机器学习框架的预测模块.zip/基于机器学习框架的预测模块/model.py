import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split

# 载入数据
data = pd.read_csv('temps.csv')

# 数据预处理
# 将时间转化为小时
data['Hour'] = pd.to_datetime(data['Time'], format='%H:%M').dt.hour

# 计算每个小时的均值
hourly_avg = data.groupby('Hour')['Value'].mean().reset_index()

# 备份原始数值，标准化数据时会修改它
scaler = MinMaxScaler(feature_range=(0, 1))
hourly_avg['Normalized Value'] = scaler.fit_transform(hourly_avg[['Value']])

# 准备数据集（使用标准化后的数值）
X = hourly_avg['Hour'].values.reshape(-1, 1)  # 时间点
y = hourly_avg['Normalized Value'].values  # 对应的标准化数值

# 将数据划分为训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 转换为 PyTorch 张量
X_train = torch.tensor(X_train, dtype=torch.float32).unsqueeze(-1)  # 添加额外维度
y_train = torch.tensor(y_train, dtype=torch.float32)
X_test = torch.tensor(X_test, dtype=torch.float32).unsqueeze(-1)  # 添加额外维度
y_test = torch.tensor(y_test, dtype=torch.float32)


# LSTM + CNN 模型定义
class LSTM_CNN(nn.Module):
    def __init__(self, input_size=1, lstm_hidden_size=64, cnn_channels=32, cnn_kernel_size=1, output_size=1):
        super(LSTM_CNN, self).__init__()

        # LSTM 层
        self.lstm = nn.LSTM(input_size, lstm_hidden_size, batch_first=True)

        # CNN 层
        self.conv1d = nn.Conv1d(in_channels=lstm_hidden_size, out_channels=cnn_channels, kernel_size=cnn_kernel_size)

        # 全连接层
        self.fc = nn.Linear(cnn_channels, output_size)

    def forward(self, x):
        # LSTM 层
        lstm_out, (h_n, c_n) = self.lstm(x)

        # CNN 层
        cnn_out = self.conv1d(lstm_out.permute(0, 2, 1))  # 调整维度顺序，适应 CNN 输入
        cnn_out = cnn_out.squeeze(-1)  # 去掉多余的维度

        # 全连接层
        out = self.fc(cnn_out)
        return out


# 实例化模型
model = LSTM_CNN()

# 损失函数和优化器
criterion = nn.MSELoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

# 训练模型
epochs = 500
for epoch in range(epochs):
    model.train()
    optimizer.zero_grad()
    # 前向传播
    y_pred = model(X_train)
    # 计算损失
    loss = criterion(y_pred.squeeze(), y_train)
    # 反向传播
    loss.backward()
    # 更新权重
    optimizer.step()

    if (epoch + 1) % 100 == 0:
        print(f'Epoch [{epoch + 1}/{epochs}], Loss: {loss.item():.4f}')

# 测试模型
model.eval()
with torch.no_grad():
    y_pred_test = model(X_test).squeeze()

# 恢复预测值的尺度（反标准化）
y_pred_test = scaler.inverse_transform(y_pred_test.reshape(-1, 1)).reshape(-1)

# 获取所有小时的真实值和预测值
y_all = hourly_avg['Value'].values
y_pred_all = model(torch.tensor(hourly_avg['Hour'].values.reshape(-1, 1), dtype=torch.float32).unsqueeze(
    -1)).detach().numpy().squeeze()
y_pred_all = scaler.inverse_transform(y_pred_all.reshape(-1, 1)).reshape(-1)

# 转换小时为 HH:00 格式
hourly_avg['Time'] = hourly_avg['Hour'].apply(lambda x: f'{int(x)}:00')

# 绘制折线图
plt.figure(figsize=(10, 6))

# 蓝色折线表示真实值的均值（未标准化）
plt.plot(hourly_avg['Time'], y_all, color='blue', marker='o', label='True Values', linestyle='-', linewidth=2)

# 红色点表示预测值（反标准化后）
plt.scatter(hourly_avg['Time'], y_pred_all, color='red', label='Predicted Values', zorder=5)

# 添加标签和标题
plt.xlabel('Hour of the Day')
plt.ylabel('Value')
plt.title('Hourly Value Prediction vs True Values')

# 设置x轴标签旋转，防止重叠
plt.xticks(rotation=45)

# 添加图例
plt.legend()

# 调整布局以避免标签重叠
plt.tight_layout()

# 显示图形
plt.show()
