<template>
    <div class="page2">
        
		<div class="container-fluid">
			<div class="row fill-h">
				<div class="col-lg-7 fill-h">
					<div class="xpanel-wrapper xpanel-wrapper-1">
						<div class="xpanel no-bg">
							<div class="fill-h" id="bar3D"></div>
						</div>
					</div>
				</div>
				<div class="col-lg-5 fill-h">
					<div class="xpanel-wrapper xpanel-wrapper-2-3">
						<div class="xpanel">
							<div class="fill-h" id="pieChart"></div> <!-- 饼状图 -->
						</div>
					</div>
					<div class="xpanel-wrapper xpanel-wrapper-1-3">
						<div class="xpanel">
							<div class="fill-h" id="bar2D" style="width: 100%; height: 100px;"></div>
						</div>
					</div>
				</div>
			</div>
		</div>
    </div>
</template>

<script>
import 'echarts-gl';

// 数据
const hours = ['0点', '1点', '2点', '3点', '4点', '5点', '6点', '7点', '8点', '9点', '10点', '11点', '12点',
				'13点', '14点', '15点', '16点', '17点', '18点', '19点', '20点', '21点', '22点', '23点'];
const days = ['北京', '上海', '广州', '深圳', '杭州', '武汉', '成都'];
const data12 = [
    [0, 0, 2], [0, 1, 3], [0, 2, 1], [0, 3, 4], [0, 4, 0], [0, 5, 1], [0, 6, 2], [0, 7, 3], [0, 8, 60], [0, 9, 75], [0, 10, 90], [0, 11, 80],
    [0, 12, 100], [0, 13, 110], [0, 14, 105], [0, 15, 95], [0, 16, 85], [0, 17, 70], [0, 18, 60], [0, 19, 50], [0, 20, 40], [0, 21, 30], [0, 22, 20], [0, 23, 10],
    [1, 0, 1], [1, 1, 0], [1, 2, 2], [1, 3, 1], [1, 4, 2], [1, 5, 3], [1, 6, 1], [1, 7, 2], [1, 8, 55], [1, 9, 70], [1, 10, 80], [1, 11, 75],
    [1, 12, 90], [1, 13, 95], [1, 14, 85], [1, 15, 80], [1, 16, 70], [1, 17, 65], [1, 18, 55], [1, 19, 45], [1, 20, 35], [1, 21, 25], [1, 22, 20], [1, 23, 10],
    [2, 0, 0], [2, 1, 1], [2, 2, 2], [2, 3, 4], [2, 4, 3], [2, 5, 2], [2, 6, 1], [2, 7, 1], [2, 8, 60], [2, 9, 75], [2, 10, 90], [2, 11, 80],
    [2, 12, 100], [2, 13, 110], [2, 14, 95], [2, 15, 85], [2, 16, 75], [2, 17, 65], [2, 18, 55], [2, 19, 50], [2, 20, 40], [2, 21, 30], [2, 22, 20], [2, 23, 15],
    [3, 0, 1], [3, 1, 1], [3, 2, 1], [3, 3, 3], [3, 4, 2], [3, 5, 2], [3, 6, 1], [3, 7, 0], [3, 8, 65], [3, 9, 80], [3, 10, 95], [3, 11, 85],
    [3, 12, 110], [3, 13, 105], [3, 14, 95], [3, 15, 85], [3, 16, 75], [3, 17, 70], [3, 18, 60], [3, 19, 50], [3, 20, 40], [3, 21, 30], [3, 22, 20], [3, 23, 10],
    [4, 0, 2], [4, 1, 3], [4, 2, 4], [4, 3, 2], [4, 4, 1], [4, 5, 1], [4, 6, 1], [4, 7, 2], [4, 8, 55], [4, 9, 70], [4, 10, 85], [4, 11, 75],
    [4, 12, 100], [4, 13, 110], [4, 14, 95], [4, 15, 85], [4, 16, 75], [4, 17, 65], [4, 18, 55], [4, 19, 50], [4, 20, 40], [4, 21, 30], [4, 22, 20], [4, 23, 10],
    [5, 0, 0], [5, 1, 1], [5, 2, 1], [5, 3, 2], [5, 4, 2], [5, 5, 3], [5, 6, 1], [5, 7, 0], [5, 8, 60], [5, 9, 70], [5, 10, 90], [5, 11, 80],
    [5, 12, 100], [5, 13, 110], [5, 14, 105], [5, 15, 95], [5, 16, 85], [5, 17, 70], [5, 18, 60], [5, 19, 50], [5, 20, 40], [5, 21, 30], [5, 22, 20], [5, 23, 15],
    [6, 0, 3], [6, 1, 2], [6, 2, 1], [6, 3, 3], [6, 4, 2], [6, 5, 3], [6, 6, 2], [6, 7, 2], [6, 8, 60], [6, 9, 75], [6, 10, 90], [6, 11, 80],
    [6, 12, 95], [6, 13, 105], [6, 14, 95], [6, 15, 85], [6, 16, 75], [6, 17, 70], [6, 18, 60], [6, 19, 50], [6, 20, 40], [6, 21, 30], [6, 22, 20], [6, 23, 10]
];
const barOpt = {
    tooltip: {
        formatter: function (params) {
            let series = params.seriesName;
            let val = params.value;
            return series + '<br/>' + days[val[1]] + '<br/>' + hours[val[0]] + '<br/>在线人数：' + val[2];
        }
    },
    visualMap: {
        max: 15,
        min: 1,
        calculable: true,
        inRange: {
            color: ['#50a3ba', '#eac736', '#d94e5d']
        },
        textStyle: {
            color: '#fff'
        }
    },
    xAxis3D: {
        type: 'category',
        data: hours
    },
    yAxis3D: {
        type: 'category',
        data: days
    },
    zAxis3D: {
        type: 'value'
    },
    grid3D: {
        boxWidth: 200,
        boxDepth: 80,
        viewControl: {
            // projection: 'orthographic'
        },
        light: {
            main: {
                intensity: 1.2,
                shadow: true
            },
            ambient: {
                intensity: 0.3
            }
        }
    },
    series: [{
        type: 'bar3D',
        data: data12.map(function (item) {
            return {
                value: [item[1], item[0], item[2]],
            }
        }),
        shading: 'lambert',

        label: {
            fontSize: 16,
            borderWidth: 1
        },

        emphasis: {
            label: {
                fontSize: 20,
                color: '#900'
            },
            itemStyle: {
                color: '#900'
            }
        }
    }]
};

/****************** 饼状图 ********************/

// 生成数据
const data = genData(10);

// 配置项
const pieOpt = {
    title: {
        text: '开源网站',
        subtext: '项目类型',
        left: 'center',
        textStyle: {
            color: '#fff'  // 设置标题"开源网站"为白色
        }
    },
    tooltip: {
        trigger: 'item',
        formatter: '{a} <br/>{b} : {c} ({d}%)'
    },
    legend: {
        type: 'scroll',
        orient: 'vertical',
        right: 10,
        top: 20,
        bottom: 20,
        data: data.legendData
    },
    series: [
        {
            name: '项目类型',
            type: 'pie',
            radius: '55%',
            center: ['40%', '50%'],
            data: data.seriesData,
            emphasis: {
                itemStyle: {
                    shadowBlur: 10,
                    shadowOffsetX: 0,
                    shadowColor: 'rgba(0, 0, 0, 0.5)'
                }
            }
        }
    ]
};


/******************* 动态横向条形图 ******************/

// 初始化数据
const dat = [];
for (let i = 0; i < 5; ++i) {
    dat.push(Math.round(Math.random() * 200));
}

// 配置项
const barOption = {
    xAxis: {
        max: 'dataMax'
    },
    yAxis: {
        type: 'category',
        data: ['深圳', '武汉', '北京', '上海', '广州'],
        inverse: true,
        animationDuration: 300,
        animationDurationUpdate: 300,
        max: 5, // 只显示最大值的前两项
        axisLabel: {
            textStyle: {
                color: '#fff'  // 设置Y轴标签（城市名称）为白色
            }
        }
    },
    series: [
        {
            realtimeSort: true,
            name: 'X',
            type: 'bar',
            barWidth: 20,
            data: dat,
            label: {
                show: true,
                position: 'right',
                valueAnimation: true
            }
        }
    ],
    legend: {
        show: true
    },
    animationDuration: 0,
    animationDurationUpdate: 3000,
    animationEasing: 'linear',
    animationEasingUpdate: 'linear'
};

function genData(count) {
    const projectTypes = [
        '软件开发', '数据分析', '网络安全', '产品设计', '市场营销',
        '人工智能', '云计算', '大数据', '区块链', '虚拟现实'
    ];  // 项目类型列表

    const legendData = [];
    const seriesData = [];

    for (let i = 0; i < count; i++) {
        // 随机选择一个项目类型
        const name = projectTypes[Math.floor(Math.random() * projectTypes.length)];
        legendData.push(name);  // 把名称加入 legendData
        seriesData.push({
            name: name,
            value: Math.round(Math.random() * 100000)  // 随机生成一个数值
        });
    }

    return { legendData: legendData, seriesData: seriesData };
}
export default {
    name: 'page2',
    props: ['selectRangeDate'],
    components: {
    },
    data() {
        return {
            bar3D: null,
            pieChart: null,
            bar2D: null,
        }
    },
    methods: {
        init() {
            try {
                // 初始化echarts实例
                this.pieChart = this.$echarts(document.getElementById("pieChart"));
                this.pieChart.setOption(pieOpt);
            } catch(e) {
                console.log(e)
            }

            try {
                this.bar2D = this.$echarts(document.getElementById("bar2D"));
                this.bar2D.setOption(barOption);
            } catch(e) {
                console.log(e)
            }

            try {
                this.bar3D = this.$echartsCanvas(document.getElementById("bar3D"));
                this.bar3D.setOption(barOpt)
            } catch(e) {
                console.log(e)
            }
        },
    },
    mounted() {
        this.init()
    },
    beforeDestroy() {
    }
}
</script>

<style lang="less" scoped>
.page2 {
    height: 100%;
    width: 100%;
    padding: 14px 20px 20px;
    overflow: hidden;


}
</style>
